// android-7 libc doesn't have timezone
long timezone = 0;
