/** Automatically generated file. DO NOT MODIFY */
package com.google.android.exoplayer.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}